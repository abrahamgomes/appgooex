package br.com.gooex_master

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
